# Bot AFK

<p align="center"> 
    <img src="https://img.shields.io/github/issues/urfate/afk-bot">
    <img src="https://img.shields.io/github/forks/urfate/afk-bot">
    <img src="https://img.shields.io/github/stars/urfate/afk-bot">
    <img src="https://img.shields.io/github/license/urfate/afk-bot">
</p>

<p align="center">
    Bot AFK dành cho Minecraft hoạt động trên các máy chủ.
</p>

<p align="center">
    Chống AFK, tự động xác thực, hỗ trợ tài khoản Microsoft và Offline.
</p>

## Cài đặt

1. [Tải xuống](https://github.com/urFate/Afk-Bot/tags) phiên bản mới nhất.
2. Tải xuống và cài đặt [Node.JS](https://nodejs.org/en/download/).
3. Chạy lệnh `npm install` trong thư mục bot.

## Sử dụng

1. Cấu hình bot trong tệp `settings.json`. [Hướng dẫn cấu hình bot có tại wiki của chúng tôi](https://urfate.gitbook.io/afk-bot/bot-configuration).
2. Khởi động bot bằng lệnh `node .`.

## Tính năng

- Mô-đun chống đá AFK (Anti-AFK Kick).
- Di chuyển đến một khối mục tiêu sau khi tham gia.
- Hỗ trợ tài khoản Mojang/Microsoft.
- Lưu nhật ký trò chuyện.
- Mô-đun tin nhắn trò chuyện.
- Tự động kết nối lại.
- Hỗ trợ các phiên bản máy chủ: `1.12 - 1.19.3`.

### Giấy phép
[MIT](https://github.com/urFate/Afk-Bot/blob/main/LICENSE)